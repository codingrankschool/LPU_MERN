import { useParams } from "react-router-dom";
import axios from "axios";

import { useState, useEffect } from "react";

export default function UserDetails() {
  let { id } = useParams();
  let [user, setUser] = useState({});

  let fetchUserById = async (id) => {
    let particularUser = await axios.get(
      `https://jsonplaceholder.typicode.com/users/${id}`
    );

    setUser(particularUser.data);
  };

  useEffect(() => {
    fetchUserById(id);
  }, [user]);

  if (!user) {
    return <h1>Loading user....</h1>;
  }

  return (
    <div style={{ border: "1px solid red" }}>
      <h1>{user.name}</h1>
      <p>{user.email}</p>
      <p>{user.website}</p>
    </div>
  );
}
