import { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

export default function User() {
  let [users, setUsers] = useState([]);

  let usersData = async () => {
    try {
      let data = await axios.get(`https://jsonplaceholder.typicode.com/users`);
      console.log(data.data);
      setUsers(data.data);
    } catch (error) {
      console.log(
        "Something Went wrong while fetching user details, error: ",
        error
      );
    }
  };

  useEffect(() => {
    usersData();
  }, []);

  if (users.length == 0) {
    return <h1>Loading....</h1>;
  }

  let divStyle = {
    border: "1px solid red",
    padding: "10px",
    margin: "10px",
  };

  return (
    <div className="users">
      {users.map(({ name, email, id }) => (
        <div style={divStyle} key={id}>
          <h1>{name}</h1>
          <p>{email}</p>
          <Link to={`user/${id}`}>Link to Know More</Link>
        </div>
      ))}
    </div>
  );
}
