import { NavLink } from "react-router-dom";

export default function Navbar() {
  let links = [
    { title: "Home", path: "/" },
    { title: "About", path: "/about" },
    { title: "Contact", path: "/contact" },
    { title: "User", path: "/user" },
    { title: "Login", path: "/login" },
  ];

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "row",
        gap: "10px",
        justifyContent: "center",
      }}
      className="nav"
    >
      {links.map(({ path, title }) => (
        <NavLink
          style={({ isActive }) => ({
            color: isActive ? "red" : "black",
          })}
          to={path}
        >
          {title}
        </NavLink>
      ))}
    </div>
  );
}
