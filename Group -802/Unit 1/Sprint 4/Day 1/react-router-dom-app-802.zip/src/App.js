import "./styles.css";

import Navbar from "./components/Navbar";
import AllRoutes from "./components/AllRoutes";

export default function App() {
  return (
    <div className="App">
      <h1>Routing in React Example</h1>
      <hr />

      <Navbar />
      <AllRoutes />
    </div>
  );
}
