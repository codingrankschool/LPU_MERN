import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <div style={{ display: "flex", justifyContent: "center", gap: "20px" }}>
      <Link to="/">Home</Link>
      <Link to="/about">ABout</Link>
      <Link to="/contact">Contact</Link>
    </div>
  );
}
