import "./styles.css";
import { useEffect, useState } from "react";

export default function App() {
  let [count, setCount] = useState(0);

  //run when component first render.
  // useEffect(() => {
  //   console.log("Component first mounted", count);
  // }, []);

  // //run when component first render and on count change
  // useEffect(() => {
  //   console.log("Component first mounted or on count change", count);

  //   //on component unmount
  //   return () => {
  //     console.log("Component unmounted", count);
  //   };
  // }, [count]);

  //this will run on every render
  // useEffect(() => {
  //   console.log(count);
  // });

  return (
    <div className="App">
      <h1>useEffect Hook in React</h1>
      <hr />

      <p>{count}</p>
      <button onClick={() => setCount(count + 1)}>Toggle Count</button>
    </div>
  );
}

/*
useEffect: It is used to maintanin the side effect of functional component in react

Note: it is also known as after render Hook

sideEffect: meaning- it maintains the entire life cycle of functional component:

1. OnRender - On Component Mount - DidMount
2. onUpdate - On Component Update - UpdateMount
3. onRemovedFromUI - on Component Unmount. - DidUnMount




*/
