import Button from "../components/Button";
import { CountDisplay } from "../components/CountDisplay";
import { useState } from "react";

export default function CounterApplication({
  count,
  incrementHandler,
  decrementHandler,
}) {
  return (
    <div>
      <CountDisplay count={count} />
      <Button title="Increment" clickHandler={incrementHandler} />
      <Button title="Decrement" clickHandler={decrementHandler} />
    </div>
  );
}
