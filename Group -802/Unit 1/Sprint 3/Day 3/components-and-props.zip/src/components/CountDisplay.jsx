export function CountDisplay({ count }) {
  return <p>{count}</p>;
}
