function Button({ title, clickHandler }) {
  // console.log(props);
  return <button onClick={clickHandler}>{title}</button>;
}

export default Button;
