import "./styles.css";
import { useState } from "react";

// import { CountDisplay } from "./components/CountDisplay";
import CounterApplication from "./components/CounterApplication";

export default function App() {
  let [count, setCount] = useState(0);

  return (
    <div className="App">
      {/* <CountDisplay count={count} />

      <Button title="Increment" clickHandler={() => setCount(count + 1)} />

      <Button title="Decrement" clickHandler={() => setCount(count - 1)} /> */}

      {/* <Button title="Register" />
      <Button title="Submit" />
      <Button title="Book Appointment" /> */}

      <CounterApplication
        count={count}
        incrementHandler={() => setCount(count + 1)}
        decrementHandler={() => setCount(count + 1)}
      />

      <CounterApplication
        count={count}
        incrementHandler={() => setCount(count + 1)}
        decrementHandler={() => setCount(count + 1)}
      />

      <CounterApplication
        count={count}
        incrementHandler={() => setCount(count + 1)}
        decrementHandler={() => setCount(count + 1)}
      />

      <CounterApplication
        count={count}
        incrementHandler={() => setCount(count + 1)}
        decrementHandler={() => setCount(count + 1)}
      />
    </div>
  );
}

/*
Component: They are piece of code that represent some specific UI.
Note: Component is resuable piece of code.


React props: it stands for properties
- It is an object in react which is used to send data from one place(one component) to another place(anoher component)
*/
