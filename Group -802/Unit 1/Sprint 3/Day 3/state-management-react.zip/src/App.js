import "./styles.css";
import { useState } from "react";

export default function App() {
  let [count, setCount] = useState(0);

  return (
    <div className="App">
      <h1>State Management In React</h1>
      <hr />

      <p>Count: {count}</p>
      <button onClick={() => setCount(count + 1)}>Increment</button>
      <button disabled={count == 0} onClick={() => setCount(count - 1)}>
        Decrement
      </button>
    </div>
  );
}
