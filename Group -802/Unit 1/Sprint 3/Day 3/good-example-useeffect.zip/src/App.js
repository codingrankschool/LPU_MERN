import "./styles.css";
import { useEffect, useState } from "react";

export default function App() {
  let [users, setUsers] = useState([]);

  let fetchUsersData = async () => {
    let response = await fetch(`https://jsonplaceholder.typicode.com/users`);
    let data = await response.json();
    setUsers(data);
  };

  useEffect(() => {
    fetchUsersData();
  }, []);

  console.log(users);

  let divStyle = {
    border: "1px solid red",
    padding: "10px",
  };

  return (
    <div className="App">
      <h1>Good Example - useEffect</h1>
      <hr />

      <div className="user-container">
        {users.map(({ name, email, phone, id }) => (
          <div style={divStyle} key={id}>
            <h1>{name}</h1>
            <p>{email}</p>
            <p>{phone}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
