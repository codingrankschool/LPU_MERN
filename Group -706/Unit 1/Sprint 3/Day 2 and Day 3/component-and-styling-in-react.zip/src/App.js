import "./styles.css";

function App() {
  let defaultStyle = {
    backgroundColor: "red",
    color: "white",
    padding: "10px",
  };

  let primaryStyle = {
    backgroundColor: "teal",
    color: "white",
    padding: "10px",
  };

  let name = "primary";

  //coditional styling.
  let finalStyle = name == "primary" ? primaryStyle : defaultStyle;

  return (
    <div
      style={{
        backgroundColor: "red",
        padding: "10px",
        color: "white",
      }}
    >
      <h1>Welcome to React</h1>

      <button
        style={
          name == "primary"
            ? {
                backgroundColor: "teal",
                color: "white",
                padding: "10px",
              }
            : {
                backgroundColor: "red",
                color: "white",
                padding: "10px",
              }
        }
      >
        Click Me
      </button>
    </div>
  );
}

export default App;
