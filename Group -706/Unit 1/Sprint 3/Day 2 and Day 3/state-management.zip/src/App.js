import "./styles.css";

import { useState } from "react";

export default function App() {
  // const [count, setCount] = useState(0);
  const [users, setUsers] = useState([]);

  // let incrementHandler = () => {
  //   setCount(count + 1);
  // };

  // let decrementHandler = () => {
  //   setCount(count - 1);
  // };

  let getUsersData = async () => {
    let response = await fetch(`https://jsonplaceholder.typicode.com/users`);
    let data = await response.json();

    // console.log(data);
    setUsers(data);
  };

  // getUsersData();

  console.log(users);

  return (
    <div className="App">
      <h1>Statement Management in React</h1>
      <hr />

      {/* <p id="counter">Count: {count}</p>
      <button onClick={() => setCount(count + 1)}>Increment</button>
      <button disabled={count == 0} onClick={() => setCount(count - 1)}>
        Decrement
      </button> */}
    </div>
  );
}
