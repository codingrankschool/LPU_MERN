import "./styles.css";
import { useEffect, useState } from "react";

export default function App() {
  let [users, setUsers] = useState([]);

  let fetchUsersData = async () => {
    let response = await fetch(`https://jsonplaceholder.typicode.com/users`);
    let data = await response.json();
    setUsers(data);
  };

  //Note: useEffect is after component render hook
  useEffect(() => {
    fetchUsersData();
  }, []);

  let divStyle = {
    border: "1px solid red",
    padding: "10px",
    margin: "10px",
  };

  return (
    <div className="App">
      <h1>USER DATA</h1>
      <hr />

      <div>
        {users.map(({ name, email, phone, id }) => (
          <div key={id} style={divStyle}>
            <h1>{name}</h1>
            <p>{email}</p>
            <p>{phone}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
