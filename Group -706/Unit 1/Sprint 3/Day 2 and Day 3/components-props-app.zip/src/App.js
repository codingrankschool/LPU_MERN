import "./styles.css";
import CounterApplication from "./components/CounterApplication";

import { useState } from "react";

//functional Component
export default function App() {
  let [count, setCount] = useState(0);
  return (
    <div className="App">
      <CounterApplication
        count={count}
        incrementHandler={() => setCount(count + 1)}
        decrementHandler={() => setCount(count - 1)}
      />

      <CounterApplication
        count={count}
        incrementHandler={() => setCount(count + 1)}
        decrementHandler={() => setCount(count - 1)}
      />

      <CounterApplication
        count={count}
        incrementHandler={() => setCount(count + 1)}
        decrementHandler={() => setCount(count - 1)}
      />
      <CounterApplication
        count={count}
        incrementHandler={() => setCount(count + 1)}
        decrementHandler={() => setCount(count - 1)}
      />
    </div>
  );
}

/*
Component: It is block of code which is related to specific UI.
Note: functional components are resuable uis

*/
