function Button({ title, clickHandler }) {
  //console.log(props); // {title: "Increment", }
  return <button onClick={clickHandler}>{title}</button>;
}

export { Button };
