import { useState } from "react";
import CountDisplay from "../components/CountDisplay";
import { Button } from "../components/Button";

function CounterApplication({ count, incrementHandler, decrementHandler }) {
  return (
    <div style={{ backgroundColor: "red", margin: "10px", padding: "10px" }}>
      <CountDisplay count={count} />
      <Button title="Increment" clickHandler={incrementHandler} />
      <Button title="Decrement" clickHandler={decrementHandler} />
    </div>
  );
}

export default CounterApplication;
