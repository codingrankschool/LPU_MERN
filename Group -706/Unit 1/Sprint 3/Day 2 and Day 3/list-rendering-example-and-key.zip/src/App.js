import "./styles.css";

export default function App() {
  let students = [
    { id: 1, name: "Sara", university: "LPU" },
    { id: 2, name: "Tulsi", university: "LPU" },
    { id: 3, name: "Pritham", university: "LPU" },
    { id: 4, name: "Rohit", university: "LPU" },
  ];

  let divStyle = {
    backgroundColor: "teal",
    color: "white",
    padding: "10px",
  };

  return (
    <div className="App">
      {students.map(({ name, university, id }) => (
        <div style={divStyle} key={id}>
          <h1>{name}</h1>
          <p>{university}</p>
        </div>
      ))}
    </div>
  );
}
